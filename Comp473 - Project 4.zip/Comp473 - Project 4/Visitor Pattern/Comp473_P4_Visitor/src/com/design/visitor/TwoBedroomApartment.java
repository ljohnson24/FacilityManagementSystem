package com.design.visitor;
//concrete visitable class
public class TwoBedroomApartment implements Visitable{
	//declared attribue
	private double price;
	//constuctor that sets price
	public TwoBedroomApartment(double price) {
		this.price = price;
	}
	//getter for price attribute
	public double getPrice() {
		return this.price;
	}

	//accept method required by visitable interface that accepts a visitor
	public double accept(Visitor visitor) {
		//passes this visitable:twobedroomapartment object
		return visitor.Visitor(this);
	}

}
