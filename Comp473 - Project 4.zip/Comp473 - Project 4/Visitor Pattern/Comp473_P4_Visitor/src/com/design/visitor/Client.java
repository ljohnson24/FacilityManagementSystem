package com.design.visitor;

public class Client {

	public static void main(String[] args) {
		//instantiate the tax and discount visitors
		TaxVisitor taxvisitor = new TaxVisitor();
		DiscountVisitor discountvisitor = new DiscountVisitor();
		//instantiate studio,one, and two bedroom apartment objects
		StudioApartment studioapartment = new StudioApartment(45.99);
		TwoBedroomApartment twobedroomapartment = new TwoBedroomApartment(24.99);
		OneBedroomApartment onebedroomapartment = new OneBedroomApartment(22.89);

		//passes each visitor type[tax and discount] each visitable type [various bedrooms] accept method, which will 
		//ultimately pass itself to the visistor's visitor methods, calling the appropriate method 
		System.out.println(studioapartment.accept(taxvisitor));
		System.out.println(studioapartment.accept(discountvisitor));
		System.out.println(onebedroomapartment.accept(taxvisitor));
		System.out.println(onebedroomapartment.accept(discountvisitor));
		System.out.println(twobedroomapartment.accept(taxvisitor));
		System.out.println(twobedroomapartment.accept(discountvisitor));
	}

}
