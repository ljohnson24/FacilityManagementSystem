package com.design.visitor;
//concrete visitable class
public class OneBedroomApartment implements Visitable{
	//declared attribute
	private double price;
	//constructor that sets price
	public OneBedroomApartment(double price) {
		this.price = price;
	}

	//getter for price attribute
	public double getPrice() {
		return this.price;
	}

	//accept method required by visitable interface that accepts a visitor
	public double accept(Visitor visitor) {
		//passes this visitable:onebedroomapartment object
		return visitor.Visitor(this);
	}
}
