package com.design.visitor;
//visitable interface
public interface Visitable {
	//method accepts visitor type
	double accept(Visitor visitor);

}
