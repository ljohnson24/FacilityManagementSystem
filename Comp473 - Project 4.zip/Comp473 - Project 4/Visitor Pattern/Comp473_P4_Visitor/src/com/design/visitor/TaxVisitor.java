package com.design.visitor;
import java.text.DecimalFormat;
//concrete visitor class
public class TaxVisitor implements Visitor {
	//formatted decimal attribute
	DecimalFormat decimalformat = new DecimalFormat("#,##");
	//default constructor
	public TaxVisitor() {
		
	}
	//visitor method for taking an onebedroomapartment object
	public double Visitor(OneBedroomApartment onebedroomapartment) {
		//prints out and return formatted price after taxes
		System.out.println("One bedroom apartment final price with tax:");
		
		return Double.parseDouble(decimalformat.format(onebedroomapartment.getPrice()*.10 + onebedroomapartment.getPrice()));
	}
	//visitor method for taking a twobedroomapartment object
	public double Visitor(TwoBedroomApartment twobedroomapartment) {
		//prints out and return formatted price after taxes
		System.out.println("Two bedroom apartment final prince with tax:");
		
		return Double.parseDouble(decimalformat.format(twobedroomapartment.getPrice()*.18 + twobedroomapartment.getPrice()));
	}
	//visitor method for taking a studioapartment object
	public double Visitor(StudioApartment studioapartment) {
		//prints out and return formatted price after taxes
		System.out.println("Studio apartment final price with tax:");
		
		return Double.parseDouble(decimalformat.format(studioapartment.getPrice()*.20 + studioapartment.getPrice()));
	}

}
