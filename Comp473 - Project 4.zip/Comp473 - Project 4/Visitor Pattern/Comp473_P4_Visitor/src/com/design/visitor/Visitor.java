package com.design.visitor;
//Visitor interface
public interface Visitor {
	//methods for visitor 
	double Visitor(OneBedroomApartment shirt);
	double Visitor(TwoBedroomApartment tshirt);
	double Visitor(StudioApartment jacket);
	}
