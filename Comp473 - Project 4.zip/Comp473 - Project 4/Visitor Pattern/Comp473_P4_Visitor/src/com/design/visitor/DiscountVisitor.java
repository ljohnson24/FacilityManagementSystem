package com.design.visitor;

import java.text.DecimalFormat;
//concrete visitor class
public class DiscountVisitor implements Visitor {
	//formatted decimal attribute
	DecimalFormat decimalformat = new DecimalFormat("#,##");
	//default constructor
	public DiscountVisitor() {
		
	}
	//visitor method for taking an onebedroomapartment object
	public double Visitor(OneBedroomApartment onebedroomapartment) {
		//prints out and return formatted discount price
		System.out.println("One bedroom apartment final price with discount:");
		
		return Double.parseDouble(decimalformat.format(onebedroomapartment.getPrice()-5));
	}
	//visitor method for taking a twobedroomapartment object
	public double Visitor(TwoBedroomApartment twobedroomapartment) {
		//prints out and return formatted discount price
		System.out.println("Two bedroom apartment final price with discount:");
		
		return Double.parseDouble(decimalformat.format( twobedroomapartment.getPrice() - 10));
	}
	//visitor method for taking a studioapartment object
	public double Visitor(StudioApartment studioapartment) {
		//prints out and return formatted dicount price
		System.out.println("Studio apartment final price with discount:");
		
		return Double.parseDouble(decimalformat.format(studioapartment.getPrice() - 3));
	}

}
