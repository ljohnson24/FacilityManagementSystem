Name: Facility taxation and discount System using Visitor Design Pattern
Author: Lashaun Johnson
Course: Comp473
Project: #4
Topic: Visitor Design Pattern

System Requirements: Windows/MacOS, Java SE 1.8

Reference:

https://dzone.com/articles/design-patterns-visitor
https://www.journaldev.com/1769/visitor-design-pattern-java
Deep Dive class notes

Source Files list:
visitor design.asta (UML Design)

src\com\design\visitor
Client.java
DicountVisitor.java
OneBedroomApartment.java
TwoBedroomApartment.java
StudioApartment.java
TaxVisitor.java
Visitable.java
Visitor.java

Description:
The purpose of this project was to demonstrate use of the visitor design pattern. Using the visitor pattern,
I was able to decouple apartment objects from the price calculation feature. This allows the difference pricing
options to be applied such as tax, discount, etc independent of the object's implementation.

Summary:
The client creates various types of apartments [visitables] which has different tax and discounts accessible through
the visitor interface. Can be extended by adding to the visitor and visitable interfaces as more concrete classes are
available oppose to changing each class implemtation.