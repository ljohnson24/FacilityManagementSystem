package com.design.composite;
//concrete room class - leaf
public class File implements Root{
	//declare object attributes
	  private String name;
	  private double size;
	  //constructor that initializes the attributes
	  public File(String name,double size){
	    this.name = name;
	    this.size = size;
	  }
	  //unimplemented method for leaf feature
	  public void add(Root root) {
	    //this is leaf node so this method is not applicable to this class.
	  }
	  //unimplemented method for leaf feature
	  public Root getChild(int i) {
	    //this is leaf node so this method is not applicable to this class.
	    return null;
	  }
	  //getter for name attribute
	  public String getName() {
	    return name;
	  }
	  //getter for size attribute
	  public double getSize() {
	    return size;
	  }
	  //prints the attributes
	  public void print() {
	    System.out.println("-------------");
	    System.out.println("Name ="+getName());
	    System.out.println("Size ="+getSize());
	    System.out.println("-------------");
	  }
	  //unimplemented method for leaf feature
	  public void remove(Root root) {
	    //this is leaf node so this method is not applicable to this class.
	  }

	}
