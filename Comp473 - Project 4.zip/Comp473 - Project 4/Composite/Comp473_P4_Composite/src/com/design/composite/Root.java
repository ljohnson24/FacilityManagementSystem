package com.design.composite;
//component interface
public interface Root {
	//behavior outline for root types
	void add(Root root);
	void remove(Root root);
	Root getChild(int i);
	String getName();
	double getSize();
	void print();

}