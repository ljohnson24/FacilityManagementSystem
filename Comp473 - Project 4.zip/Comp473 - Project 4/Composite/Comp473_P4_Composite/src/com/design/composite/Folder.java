package com.design.composite;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
//concrete root class - composite provisions
public class Folder implements Root{
//declare attributes
 private String name;
 private double size;
//constructor that initializes attributes
 public Folder(String name,double size){
  this.name = name;
  this.size = size;
 }
 //iniializes arraylist of root types
 List<Root> roots = new ArrayList<Root>();
 //adds root types the list
 public void add(Root root) {
    roots.add(root);
 }
//retrieves root type from the list
 public Root getChild(int i) {
  return roots.get(i);
 }
//getter for name attribute
 public String getName() {
  return name;
 }
//getter for size attribute
 public double getSize() {
  return size;
 }
//prints the attributes
 public void print() {
  System.out.println("-------------");
  System.out.println("Name ="+getName());
  System.out.println("Size ="+getSize());
  System.out.println("-------------");
  //iterates through the composite objects (recursion)
  Iterator<Root> employeeIterator = roots.iterator();
    while(employeeIterator.hasNext()){
     Root root = employeeIterator.next();
     root.print();
    }
 }
//removes the root type from the list
 public void remove(Root root) {
  roots.remove(root);
 }

}