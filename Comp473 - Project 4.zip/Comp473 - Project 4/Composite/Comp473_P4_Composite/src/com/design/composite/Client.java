package com.design.composite;

public class Client {

	public static void main(String[] args) {
		//instantiates the files
		  Root file1=new File("jump.vid", 32);
		  Root file2=new File("picture.jpg", 64);
		  //instantiates the folder
		  Root folder1=new Folder("My Files",128);
		  //adds the two file to  the folder
		  folder1.add(file1);
		  folder1.add(file2);
		  //instantiates a new file
		  Root file3=new File("song.mp3", 16);
		  //instantiates a new folder
		  Root folder2=new Folder("Administrator", 512);
		  //adds the new file to the new folder
		  folder2.add(file3);
		  //adds the old folder to the new folder
		  folder2.add(folder1);
		  //prints out the root directory and files recursively
		  folder2.print();
		 }

}
