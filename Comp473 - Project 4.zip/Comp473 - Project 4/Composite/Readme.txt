Name: Computer File system using Composite Design Pattern
Author: Lashaun Johnson
Course: Comp473
Project: #4
Topic: Composite Design Pattern

System Requirements: Windows/MacOS, Java SE 1.8

Reference:

https://dzone.com/articles/composite-design-pattern-java-0
Deep Dive class notes

Source Files list:
Composite pattern.asta (UML Design)

src\com\design\visitor
Client.java
File.java
Folder.java
Root.java

Description:
The purpose of this project was to demonstrate use of the composite design pattern. Using the composite pattern,
I was able to capture and represent an object with object type anatomy [composite and leaf] in a tree structure. This 
allowed each node to be called and operated on. This allow allow generalization for individual objects and compositions 
of objects. 

Summary:
The client creates various types of files and folders [composite and leaf] which composite has child and leafs does not.The
files are then added to the folder. Then a new file and the initial folder is added to a new folder and iterated through
to demonstrate the tree structure. The root folder and contained files are listed first, then subfolders and thier files
as would a computer file system.