package com.design.bridge;
//wood material implementation class than extends IMaterial interface
public class Wood implements IMaterial {

	//overrides IMaterial method signature
	@Override
	public String build() {
		//returns material type
		return "built with wood material";
	}

}
