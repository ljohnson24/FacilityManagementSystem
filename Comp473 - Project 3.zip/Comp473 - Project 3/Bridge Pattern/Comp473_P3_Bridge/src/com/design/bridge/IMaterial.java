package com.design.bridge;

public interface IMaterial {
	String build();

}
