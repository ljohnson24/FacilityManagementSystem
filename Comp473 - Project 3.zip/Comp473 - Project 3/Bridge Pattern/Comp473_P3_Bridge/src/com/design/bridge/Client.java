package com.design.bridge;

public class Client {

	public static void main(String[] args) {
		//instantiate facility objects using bridge references IColor and IMaterial
		Facility facility1 = new Apartment(new Yellow(), new Brick());
		facility1.render();
		Facility facility2 = new OfficeBuilding(new Red(), new Wood());
		facility2.render();
		
	}

}
