package com.design.bridge;

//
public interface IColor {
	String paint();

}
