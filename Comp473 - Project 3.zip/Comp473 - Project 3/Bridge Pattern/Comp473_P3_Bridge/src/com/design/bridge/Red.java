package com.design.bridge;
//color implemmentation class
public class Red implements IColor {
	//overrides the icolor interface signature
	@Override
	public String paint() {
		//returns color
		return "Painted Blue";

	}

}
