package com.design.bridge;
//refine abstracted facility class bridge pattern
public class OfficeBuilding extends Facility {
	//constructor
	public OfficeBuilding(IColor color, IMaterial material) {
		super(color, material);
	}
	
	//overrides the facility interface/abstraction signature methods
	@Override
	public void render() {
		//prints facility type
		System.out.println("OfficeBuilding: ");
		//prints color painted
		System.out.println(color.paint());
		//prints material use to build
		System.out.println(material.build());
	}

}
