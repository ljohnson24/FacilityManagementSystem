package com.design.bridge;
//refine abstraction  in bridge pattern
public class Apartment extends Facility {
	//constructor
	public Apartment(IColor color, IMaterial material) {
		//calls the parent:Facility constructor
		super(color, material);
	}

	//overrides inherited facility signatures
	@Override
	public void render() {
		//prints facility type
		System.out.println("Apartment: ");
		//prints painted color
		System.out.println(color.paint());
		//prints material used to build
		System.out.println(material.build());
	}
}
