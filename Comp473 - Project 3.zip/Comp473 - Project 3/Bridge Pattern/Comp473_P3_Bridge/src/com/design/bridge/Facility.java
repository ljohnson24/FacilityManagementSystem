package com.design.bridge;

/// abstraction in bridge pattern 
public abstract class Facility {
	protected IColor color;
	protected IMaterial material;
	
	//constructor that takes attributes as parameters
	public Facility(IColor color, IMaterial material) {
		this.color = color;
		this.material = material;
	}
	
	abstract public void render();

}
