package com.design.bridge;
//color implemtation classs
public class Yellow implements IColor {

	//overrides the IColor interface signature
	@Override
	public String paint() {
		//returns yellow
		return "Painted Yellow";
	}

}
