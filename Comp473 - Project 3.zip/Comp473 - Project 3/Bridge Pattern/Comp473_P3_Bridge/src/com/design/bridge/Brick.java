package com.design.bridge;
//brick material implementation class the extends IMateral interface
public class Brick implements IMaterial {
	//overrides the IMaterial method signature
	@Override
	public String build() {
		return "Built with brick material";

	}

}
