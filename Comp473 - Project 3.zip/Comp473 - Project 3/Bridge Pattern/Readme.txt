Name: Facility Build and Rendering System using Bridge Design Pattern
Author: Lashaun Johnson
Course: Comp473
Project: #3
Topic: Bridge Design Pattern

System Requirements: Windows/MacOS, Java SE 1.8

Reference:

https://www.geeksforgeeks.org/bridge-design-pattern/
https://www.geeksforgeeks.org/observer-pattern-set-1-introduction/
http://www.baeldung.com/java-structural-design-patterns

Source Files list:
BridgePattern.asta (UML Design)

src\com\design\bridge
Apartment.java
Brick.java
Client.java
Facility.java
IColor.java
IMaterial.java
OfficeBuilding.java
Red.Java
Wood.java
Yellow.java

Description:
The purpose of this project was to demonstrate use of the bridge design pattern. Using the bridge pattern,
I was able to decouple Facility and Color/Material interfaces. This allows abstraction and implementation
to vary independently. This boast the open-close principle, which grants extensibility without having to
change the structure of a class.

Summary:
The client creates various types of facilities, which can be built with various material, and painted
with various colors. The abstract facility class could have many refinements, and the bridge reference
interface could have multiple implementations.