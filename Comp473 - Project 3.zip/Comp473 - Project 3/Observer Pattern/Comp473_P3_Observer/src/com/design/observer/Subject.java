package com.design.observer;
//interface that describes the behavior of the subject notification system
public interface Subject {
	//accepts an subscriber to be added to the notification list
	public void register(Observer observer);
	//accepts subscriber to be removed from the notification list
	public void unregister(Observer observer);
	//enables the system to notify all subscribers on the notification list
	public void notifyObservers();
	//retrieves the latest data 
	public  Object getUpdate(Observer observer);
	

}
