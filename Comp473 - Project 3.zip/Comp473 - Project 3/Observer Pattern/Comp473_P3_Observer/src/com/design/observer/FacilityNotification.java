package com.design.observer;

import java.util.ArrayList;
import java.util.List;
//defines the notification system, extends the subject interface
public class FacilityNotification implements Subject {
	//declare a list of subscribers
	private List<Observer> observers;
	//declares content to be updated and posted
	private String message;
	
	//constructor that initializes the subscription list
	public FacilityNotification() {
		this.observers = new ArrayList<>();
	}
	
	//allows a subscriber to be added to the notification list
	@Override
	public void register(Observer observer) {
		//exception thrown if observer is not initialized
		if(observer == null) throw new NullPointerException("Null object/ Observer");
		//adds the subscriber to the notification list only if it does not exist already
		if(!observers.contains(observer)) {
			//adds the subscriber
			observers.add(observer);
		}

	}
	//allows the subscriber to unsubscribe
	@Override
	public void unregister(Observer observer) {
		//removes the subscriber from the notification list
		observers.remove(observer);

	}
	//sends out notifications to all the subscriber on the list
	@Override
	public void notifyObservers() {
		//iterates thru all of the subscriber on the notification list
		for (Observer observer:observers) {
			//update each subscriber with the latest content
			observer.update();
		}

	}
	//retrieves the subscribers latest content
	@Override
	public Object getUpdate(Observer observer) {
		
		return this.message;
	}
	//allow content to be updated
	public void postMessage(String message) {
		//displays the content entry
		System.out.println("Message posted to my topic: "+ message);
		//sets the content
		this.message = message;
		//sends notifications to all subscribers of the content change
		notifyObservers();
	}

}
