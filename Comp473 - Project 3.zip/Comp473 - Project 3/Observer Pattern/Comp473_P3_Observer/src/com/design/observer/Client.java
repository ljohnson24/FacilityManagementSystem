package com.design.observer;

public class Client {

	public static void main(String[] args) {
		//initializes the notification system
		FacilityNotification topic = new FacilityNotification();
		
		//create subscribers
		Observer peoplerealty = new Realtor("peoplerealty");
		Observer clkchicago = new Realtor("clkchicago");
		Observer downtowninvestors = new Realtor("downtowninvestors");

		//register subscribers
		topic.register(peoplerealty);
		topic.register(clkchicago);
		topic.register(downtowninvestors);
		
		//attaching subscribers to the subject
		peoplerealty.setSubject(topic);
		clkchicago.setSubject(topic);
		downtowninvestors.setSubject(topic);
		
		//check for updates prior to any notifications
		peoplerealty.update();
		
		//provider, which is a subject broadcaster
		topic.postMessage("Condo - 3bed,2bath - Available - June 1st");
		//an subscriber is removed from the notification list after the update
		topic.unregister(clkchicago);
		//a new notification is sent out excluding those who had unsubscribed
		topic.postMessage("Condo - 3bed,2bath - Unavailable");
		
		
	}

}
