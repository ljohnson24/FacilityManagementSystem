package com.design.observer;
//subscriber implementation extends the observer interface
public class Realtor implements Observer {
	//declares a name and provision for a subject
	private String name;
	private Subject topic;

	//constructor that sets the name
	public Realtor(String name) {
		
		this.name = name;
		
	}
	//allows the subscriber to check for latest content
	@Override
	public void update() {
		//store the latest subscribed content
		String msg = (String) topic.getUpdate(this);
		
		if (msg == null) {
			System.out.println(name + " No new message on this topic");
		}
		
		else
			System.out.println(name + " Retrieving message: " + msg);
	}
	
	//allows the subscriber to attach itself to a subject
	@Override
	public void setSubject(Subject subject) {
		//sets the subject that contains subscription content
		this.topic = subject;

	}

}
