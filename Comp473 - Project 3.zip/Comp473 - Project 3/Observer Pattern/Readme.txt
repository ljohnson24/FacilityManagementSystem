Name: Facility Notification System using Observer Design Pattern
Author: Lashaun Johnson
Course: Comp473
Project: #3
Topic: Observer Design Pattern

System Requirements: Windows/MacOS, Java SE 1.8

Reference:

https://www.geeksforgeeks.org/observer-pattern-set-1-introduction/

Source Files list:
ObserverPattern.asta (UML Design)

src\com\design\observer
Client.java
FacilityNotification.java
Observer.java
Realtor.java
Subject.java

Description:
The purpose of this project was to demonstrate use of the observer design pattern. Using the observer pattern,
I was able to create a loosly coupled system. This allowed the Realtor and the FacilityNotificaton objects to 
interact with knowing minimum information about one another. In addition, there is no need to modify the subject
to add or remove subscribers. Also, the design pattern boasts reusability.

Summary:
The client creates is creates an observer and a subject object. The observer services as the subscriber and the 
subject services as the broadcaster in the notification system. Multiple subscribers are created and substribes
to the notification system. The broadcaster posts the new content and notifies all subscriber on the notification
list. Each subscriber on the notification list is updated with the lastest content.