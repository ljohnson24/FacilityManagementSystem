package com.fms.model.facility;

public interface IFacilityDetail {
	public String getFacilityName();
	public void setFacilityName(String facilityname);
	public String getFacilityDescription();
	public void setFacilityDescription(String facilitydescription);
	public int getFacilityPhone();
	public void setFacilityPhone(int facilityphone);
	public String getFacilityAddress();
	public void setFacilityAddress(String facilityaddress);
	

}
