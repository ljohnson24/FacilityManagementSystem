package com.fms.model.facilityinspection;

public interface IInspector {
	String getInspectorName();
	void setInspectorName(String inspectorname);
	String getInspectorID();
	void setInspectorID(String inspectorid);
}
