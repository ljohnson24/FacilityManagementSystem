package com.fms.model.facility;

public interface IBuildingDetail {
	
	String getBuildingName();
	void setBuildingName(String buildingname);
	String getBuildingAddress();
	void setBuildingAddress(String buildingaddress);
	int getBuildingPhone();
	void setBuildingPhone(int buildingphone);
	
}
