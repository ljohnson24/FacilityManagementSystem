package com.fms.model.facilityuse;

public interface IUser {

	public String getUserID();
	public void setUserID(String userid);
	public IUserDetail getUserDetail();
	public void setUserDetail(IUserDetail userdetail);
}
