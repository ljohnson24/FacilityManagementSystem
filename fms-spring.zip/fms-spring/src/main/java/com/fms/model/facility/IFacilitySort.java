package com.fms.model.facility;

import java.util.List;

public interface IFacilitySort {
	
	List<IBuilding> sortByName(List<IBuilding> buildings);

}
