package com.fms.model.facilityuse;

public interface IUserDetail {
	public String getUserName();
	public void setUserName(String username);
	public String getUserAddress();
	public void setUserAddress(String useraddress);
	public String getUserEmail();
	public void setUserEmail(String useremail);
	public int getUserPhone();
	public void setUserPhone(int userphone);
}
