package com.fms.view;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fms.model.facility.Building;
import com.fms.model.facility.Facility;
import com.fms.model.facility.FacilityFilter;
import com.fms.model.facility.IBuilding;
import com.fms.model.facility.IBuildingDetail;
import com.fms.model.facility.IFacility;
import com.fms.model.facility.IFacilityDetail;
import com.fms.model.facility.IFacilityFilter;
import com.fms.model.facility.IRoom;
import com.fms.model.facilityinspection.IInspection;
import com.fms.model.facilityinspection.IInspectionDetail;
import com.fms.model.facilityinspection.IInspector;
import com.fms.model.facilityinspection.Inspection;
import com.fms.model.facilityinspection.InspectionDetail;
import com.fms.model.facilityinspection.Inspector;
import com.fms.model.facilitymaintenance.FacilityMaintenance;
import com.fms.model.facilitymaintenance.IFacilityMaintenance;
import com.fms.model.facilityuse.FacilitySchedule;
import com.fms.model.facilityuse.FacilityUse;
import com.fms.model.facilityuse.IFacilitySchedule;
import com.fms.model.facilityuse.IFacilityUse;
import com.fms.model.facilityuse.IUser;
import com.fms.model.facilityuse.IUserDetail;


public class MainSpring {

	public static void main(String[] args) {
		//create the application context (container)
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		
		//create the  2 user beans
		IUserDetail user1detail, user2detail;
		user1detail = (IUserDetail) ctx.getBean("UserDetail1");
		user2detail = (IUserDetail) ctx.getBean("UserDetail1");
		IUser user1, user2;
		user1 = (IUser) ctx.getBean("User1");
		user2 = (IUser) ctx.getBean("User2");
		//prints both users
		System.out.println("User1: "+ user1 + "\nUser2: "+user2);
		
		
		//Creates Inspection department _-> inspector with details and inspection
		IInspector inspector = (IInspector) ctx.getBean("Inspector");
		IInspectionDetail inspectiondetail = (IInspectionDetail) ctx.getBean("InspectionDetail");
		IInspection inspection = (IInspection) ctx.getBean("Inspection");
		//prints out inspection
		System.out.println("\nInspection 1: "+inspection);
		
		//Creates a facility
		//Schedule
		IFacilitySchedule facilityschedule = (IFacilitySchedule) ctx.getBean("FacilitySchedule");
		
		//facility detail
		IFacilityDetail facilitydetail = (IFacilityDetail) ctx.getBean("FacilityDetail");
		
		//creates building group
		IBuildingDetail buildingdetail = (IBuildingDetail) ctx.getBean("BuildingDetail1");
		IBuildingDetail buildingdetail2 = (IBuildingDetail) ctx.getBean("BuildingDetail2");
		ArrayList<IBuilding> buildings = (ArrayList<IBuilding>) ctx.getBean("buildings");
		
		//creates rooms
		@SuppressWarnings("unchecked")
		ArrayList<IRoom> rooms = (ArrayList<IRoom>) ctx.getBean("rooms");
		@SuppressWarnings("unchecked")
		ArrayList<IRoom> rooms2 = (ArrayList<IRoom>) ctx.getBean("rooms2");
		IRoom room1 = (IRoom) ctx.getBean("Room1");
		IRoom room2 = (IRoom) ctx.getBean("Room2");
		IRoom room3 = (IRoom) ctx.getBean("Room3");
		IRoom room4 = (IRoom) ctx.getBean("Room4");
		IRoom room5 = (IRoom) ctx.getBean("Room5");
		
		//adds rooms to the room container
		rooms.add(room1);
		rooms.add(room2);
		rooms.add(room3);
		rooms.add(room4);
		rooms.add(room5);
		rooms2.add(room5);
		
		//assembly building
		
		IBuilding building = (IBuilding) ctx.getBean("Building");
		IBuilding building2 = (IBuilding) ctx.getBean("Building2");
				
		//add building to list of buildings
		buildings.add(building);
		buildings.add(building2);
				
		//prints buildings and room
		System.out.println("\nBuildings: "+buildings);
		
		
		//Creates Maintenance department
		IFacilityMaintenance facilitymaintenance = (IFacilityMaintenance) ctx.getBean("FacilityMaintenance");
		facilitymaintenance.requestRoomMaintenance(room2);
				
		//print maintenance request
		System.out.println("\nFacility Maintenance Request: "+facilitymaintenance.getFacilityMaintenanceRequestList());
				
		//assembly facility
		IFacility facility = (IFacility) ctx.getBean("Facility");
		//facility.addBuilding(building);
		facility.addBuilding(building2);
		
		//Creates FacilityUse department
		IFacilityUse facilityuse = (IFacilityUse) ctx.getBean("FacilityUse");
				
		//Facility use
		facilityuse.addUser(user1);
		facilityuse.addUser(user2);
		facilityuse.assignFacilityToUse("01", "0001");
		facilityuse.assignFacilityToUse("03", "0001");
		facilityuse.assignFacilityToUse("01","0002");
		System.out.println("\nFacility: room1 usage rate: " +facilityuse.calcUsageRate("01"));
		System.out.println("Facility: room2 usage rate: " +facilityuse.calcUsageRate("02"));
		System.out.println("\nFacility: room1 actual usage list: "+facilityuse.listActualUsage("01"));
				
		IFacilityFilter facilityfilter = new FacilityFilter();
		System.out.println("\nList only occupied buildings:\n" + facilityfilter.filterByOccupancy(facility.getBuildings()));
		System.out.println("\nList only buildings that has vacancies:\n" + facilityfilter.filterByVacancy(facility.getBuildings()));
		
		System.out.println(room1.getRoomStatus());
		
		//invoke the company slogan via the bean
		//org.corporateSlogan();
		
		//close the application context (container)
		((ClassPathXmlApplicationContext) ctx).close();

	}

}
